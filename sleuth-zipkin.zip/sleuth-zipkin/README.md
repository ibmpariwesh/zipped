localhost:8082/product/test

product will call inventory