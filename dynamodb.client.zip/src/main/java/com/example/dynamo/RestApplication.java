package com.example.dynamo;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.example.dynamo.repo.ProductInfoRepository;

@ComponentScan
@SpringBootApplication // meta annotation
public class RestApplication {

	@Autowired
	 ProductInfoRepository repository ;
	public static void main(String[] args) {
		SpringApplication.run(RestApplication.class, args);//.getBean(ProductInfoRepository.class);
		ProductInfo productInfo = new ProductInfo(100, 200);
		new RestApplication().extracted(productInfo);
		
	}
	private  void extracted(ProductInfo productInfo) {
		repository.save(productInfo);
		List<ProductInfo> result = (List<ProductInfo>) repository.findAll();
	}
}
